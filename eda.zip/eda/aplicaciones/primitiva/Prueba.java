package aplicaciones.primitiva;


/**
 * Write a description of class Prueba here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Prueba {
    // instance variables - replace the example below with your own
    public static void main(String[] args){
        ApuestaPrimitiva ap;
        for(int i = 0;i < 2500;i++){
            ap = new ApuestaPrimitiva(true);
            repe(ap.toString().split(","));
            System.out.println(ap.toString());
        }
        for(int i = 0;i < 2500;i++){
            ap = new ApuestaPrimitiva(false);
            repe(ap.toString().split(","));
            //System.out.println(ap.toString());            
        }
    }
    
    public static void repe(String[] x){
        int[] r = new int[6];
        for(int i = 0;i < x.length;i++){
            for(int j = 0;j < x.length;j++){
                if(x[i].equals(x[j])) r[i]++;            
            }
        }
        for(int k = 0;k < r.length;k++){
            if(r[k] > 1) System.out.println("Repetido");
        }
    }
}
