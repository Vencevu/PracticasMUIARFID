package librerias.estructurasDeDatos.lineales;


/**
 * Write a description of class LEGListaConPIOrdenada here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LEGListaConPIOrdenada<E extends Comparable> extends LEGListaConPI<E>{
    /**
     * Constructor for objects of class LEGListaConPIOrdenada
     */
    public LEGListaConPIOrdenada() {
        super();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void insertar(E e) {
        NodoLEG<E> nuevo = new NodoLEG<E>(e); talla++;
        
        this.inicio();
        if(!this.esFin()){
            while(!this.esFin()){
                if(nuevo.dato.compareTo(this.recuperar()) > 0){
                    this.siguiente();
                }else{break;}
            }
            nuevo.siguiente = ant.siguiente;
            ant.siguiente = nuevo;
        }else{
            nuevo.siguiente = ant.siguiente;
            ant.siguiente = nuevo;
        }
        if (ant  ==  ult) { ult = nuevo;}
    }
    
    /*public int compareTo(Object o) {
        if(o instanceof LEGListaConPIOrdenada){
            if(((LEGListaConPIOrdenada)o).esVacia() && this.esVacia()){return 1;}
            ((LEGListaConPIOrdenada)o).inicio();
            this.inicio();
            if (this.talla() != ((LEGListaConPIOrdenada)o).talla) {return 0;}
            
                while(!this.esFin()){
                 if(((LEGListaConPIOrdenada)o).ant == null) {return 0;}
                 if(this.ant.dato != ((LEGListaConPIOrdenada)o).ant.dato){return 0;}
                 this.siguiente(); ((LEGListaConPIOrdenada)o).siguiente();
            }
            if(this.ant.dato == ((LEGListaConPIOrdenada)o).ant.dato) {return 1;}
            return 0;
        }
        return 0;
    }*/
}
