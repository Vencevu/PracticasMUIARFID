/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pract4;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author alcargra
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private ToggleGroup compra;
    @FXML
    private MenuItem salir;
    @FXML
    private Label estado;
    @FXML
    private Menu opcionesmenu;
    @FXML
    private Menu comprarmenu;
    @FXML
    private RadioMenuItem amazonmenu;
    @FXML
    private RadioMenuItem ebaymenu;
    @FXML
    private Button amazon;
    @FXML
    private ImageView bing;
    @FXML
    private ImageView ebay;
    @FXML
    private ImageView facebook;
    @FXML
    private ImageView googleplus;
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void exit(ActionEvent event) {
        Alert a = new Alert(AlertType.CONFIRMATION);
        a.setTitle("Salida.");
        a.setHeaderText("Va a salir del programa.");
        a.setContentText("¿Seguro que quiere salir?");
        
        Optional<ButtonType> r = a.showAndWait();
        if(r.isPresent() && r.get() == ButtonType.OK){
            System.exit(0);
        }
    }

    @FXML
    private void amazonaccion(ActionEvent event) {
        Alert a = new Alert(AlertType.INFORMATION);
        if(amazonmenu.isSelected()){
            a.setTitle("Confirmación");
            a.setHeaderText("Compra realizada correctamente");
            a.setContentText("Has comprado en Amazon.");}
        else{
            a.setTitle("Error en la selección");
            a.setHeaderText("No puede comprar en Ebay");
            a.setContentText("Por favor, cambie la selección actual en el menú Opciones.");}
            a.showAndWait();
    }

    @FXML
    private void bingaccion(MouseEvent event) {
    }

    @FXML
    private void ebayaccion(MouseEvent event) {
    }

    @FXML
    private void facebookaccion(MouseEvent event) {
    }

    @FXML
    private void googleaccion(MouseEvent event) {
    }


    
}
