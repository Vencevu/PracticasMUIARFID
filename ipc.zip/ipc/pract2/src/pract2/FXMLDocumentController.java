/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pract2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import java.util.regex.*;
import javafx.scene.control.TextField;

/**
 *
 * @author alcargra
 */
public class FXMLDocumentController implements Initializable{
    
    @FXML
    private Label resultado;
    @FXML
    private Button uno;
    @FXML
    private Button cinco;
    @FXML
    private Button diez;
    @FXML
    private CheckBox restar;
    @FXML
    private TextField valor;
    @FXML
    private Button operacion;
    @FXML
    private Label aviso;
    
    private int res;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        restar.selectedProperty().addListener(( o, oldVal, newVal) -> {
            if(newVal) {operacion.setText("Restar"); aviso.setVisible(true);}
            else {operacion.setText("Sumar"); aviso.setVisible(false);}
        });
        valor.textProperty().addListener((o, oldVal, newVal) -> {
            String pattern = "[0-9]*";
            if(!Pattern.matches(pattern, newVal)){
                valor.setText(oldVal);
            }
        });
    }    

    @FXML
    private void sumarUno(ActionEvent event) {
        if(aviso.isVisible()){res--;}
        else{res++;}
        resultado.setText(String.valueOf(res));
    }

    @FXML
    private void sumarCinco(ActionEvent event) {
        if(aviso.isVisible()){res-=5;}
        else{res+=5;}        
        resultado.setText(String.valueOf(res));
    }

    @FXML
    private void sumarDiez(ActionEvent event) {
        if(aviso.isVisible()){res-=10;}
        else{res+=10;}
        resultado.setText(String.valueOf(res));
    }

    @FXML
    private void operar(ActionEvent event) {
        if(!valor.getText().equals("")){
            int calc = Integer.valueOf(valor.getText());
            if(aviso.isVisible()){res-=calc;}
            else{res+=calc;}
            resultado.setText(String.valueOf(res));
        }
    }

}
