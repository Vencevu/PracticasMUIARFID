package controlador;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import modelo.Persona;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListCell;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class VistaListaControlador implements Initializable {

    @FXML
    private Button BModificarfxID1;
    @FXML
    private TableView<Persona> tableView;

    @FXML
    private void modificarAccion(ActionEvent event) throws Exception {
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/vista/ComoTeSalgaDeLosHuevos.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.setTitle("Modificar");
        stage.show();
    }
	
    
    class PersonaLista extends ListCell<Persona>{
        @Override
        protected void updateItem(Persona item, boolean empty){
            super.updateItem(item, empty);
            if(item == null || empty) setText(null);
            else setText(item.getApellidos() + ", " + item.getNombre());
        }
    }
	
    private ListView<Persona> vistadeListafxID;

    @FXML private Button BAddfxID;
    @FXML private Button BBorrarfxID;
    
    @FXML void addAccion(ActionEvent event) throws Exception{
        // añade a la colección si los campos no son vacíos y no contienen únicamente blancos
         /*if ((!textFieldfxID.getText().isEmpty())
        	&& (textFieldfxID.getText().trim().length()!=0)
        	&& (!textFieldApellidofxID.getText().isEmpty())
        	&& (textFieldApellidofxID.getText().trim().length()!=0))
         { 
           datos.add(new Persona(textFieldfxID.getText(),textFieldApellidofxID.getText()));
           textFieldfxID.clear();
           textFieldApellidofxID.clear();
           textFieldfxID.requestFocus();  //cambio del foco al textfield.
        	 
         } */
        Stage stage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/vista/ComoTeSalgaDeLosHuevos.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.setTitle("Añadir");
        stage.show();

    }


    @FXML void borrarAccion(ActionEvent event) {
    }
	
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		               

	
	}
	


        
        
}
