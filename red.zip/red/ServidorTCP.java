import java.net.*;
import java.io.*;
import java.util.*;
public class ServidorTCP {
    public static void main(String[] args){
        try{
            ServerSocket ss = new ServerSocket(8000);
            while(true){
                Socket s = ss.accept();
                Scanner in = new Scanner(s.getInputStream());

                PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                
                String men = in.nextLine();
                
                while(!men.equals("")){
                    out.println(men);
                    men = in.nextLine();
                }
                
                in.close();
                out.close();
                s.close();
            }
        }catch(IOException e){System.out.println(e);}
    }
}
