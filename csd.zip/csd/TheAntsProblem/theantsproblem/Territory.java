package theantsproblem;

import java.util.concurrent.locks.*;
import java.util.concurrent.*;;

public class Territory {
    private int tam; // Matrix size
    private boolean occupied[][];
    String description = "Using Barriers";
    private Log log;

    Lock lock;
    Condition[][] c;
    //CountDownLatch barrera;
    public String getDesc() {
        return description;
    }

    public Territory(int tamT, Log l) {
        lock = new ReentrantLock();
        tam = tamT;
        c = new Condition[tam][tam];
        occupied = new boolean[tam][tam];
        log = l;
        //barrera = new CountDownLatch(1);
        // Initializing the matrix
        for (int i = 0; i < tam; i++) {
            for (int j = 0; j < tam; j++) {
                occupied[i][j] = false;
                c[i][j] = lock.newCondition();
            }
        }
    }

    public int getTam() {
        return tam;
    }

    public void putAnt(Ant h, int x, int y) {
        
        while (occupied[x][y]) {
            
            try {
                //barrera.await();
                lock.lock();
                // Write in the log: ant waiting
                log.writeLog(LogItem.PUT, h.getid(), x, y, LogItem.WAITINS,
                        "Ant " + h.getid() + " waiting for [" + x + "," + y + "]");
                c[x][y].await(500,TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
            }finally{lock.unlock();}
        }
        occupied[x][y] = true;
        h.setPosition(x, y);
        // Write in the log: ant inside territory
        log.writeLog(LogItem.PUT, h.getid(), x, y, LogItem.OK, "Ant " + h.getid() + " : [" + x + "," + y + "]  inside");
    }

    public void takeAnt(Ant h) {
        int x = h.getX();
        int y = h.getY();
        occupied[x][y] = false;
        // Write in the log: ant outside territory
        log.writeLog(LogItem.TAKE, h.getid(), x, y, LogItem.OUT, "Ant " + h.getid() + " : [" + x + "," + y + "] out");
    }

    public void moves(Ant h, int x1, int y1, int step) {
        int x = h.getX();
        int y = h.getY();
        int w = 0;
        try{
            lock.lock();
            while (occupied[x1][y1]) {
                // Write in the log: ant waiting
                log.writeLog(LogItem.MOVE, h.getid(), x1, y1, LogItem.WAIT, "Ant " + h.getid() + " waiting for [" + x1 + "," + y1 + "]");
                c[x][y].await(700,TimeUnit.MILLISECONDS);
                c[x][y].signalAll();
                w++;
                if(w>=10){
                    int x2 = x; int y2 = y;
                    if(x1>x && x>0){x2--;}
                    else if(x1<x && y>0){y2--;}
                    else if(y1<x && y<tam-1){y++;}
                    else if(y1>x && x<tam-1){x++;}
                    x1 = x2; y1 = y2;
                    break;
                }
            }
            occupied[x][y] = false;
            occupied[x1][y1] = true;
            if(x == 0){
                    if(y == 0) {
                        c[x][y+1].signalAll();
                    }else if(y == tam - 1){
                        c[x][y-1].signalAll();
                    }else{
                        c[x][y+1].signalAll();
                        c[x][y-1].signalAll();
                    }
                    c[x+1][y].signalAll();
                }else if(x == tam - 1){
                    if(y == 0) {
                        c[x][y+1].signalAll();
                    }else if(y == tam - 1){
                        c[x][y-1].signalAll();
                    }else{
                        c[x][y+1].signalAll();
                        c[x][y-1].signalAll();
                    }
                    c[x-1][y].signalAll();
                }else if(y == tam - 1){
                    c[x-1][y].signalAll();
                    c[x+1][y].signalAll();
                    c[x][y-1].signalAll();
                }else if(y == 0){
                    c[x-1][y].signalAll();
                    c[x+1][y].signalAll();
                    c[x][y+1].signalAll();
                }else{
                    c[x-1][y].signalAll();
                    c[x+1][y].signalAll();
                    c[x][y+1].signalAll();
                    c[x][y-1].signalAll();
                }
            h.setX(x1);
            h.setY(y1);
            // Write in the log: ant moving
            log.writeLog(LogItem.MOVE, h.getid(), x1, y1, LogItem.OK,
                    "Ant " + h.getid() + " : [" + x + "," + y + "] -> [" + x1 + "," + y1 + "] step:" + step);
        }catch(InterruptedException e){
        }finally{lock.unlock();}
    }
}
