// CSD Mar 2013 Juansa Sendra

public class LimitedTable extends RegularTable { //max 4 in dinning-room
    public int filosofos = 0;
    public LimitedTable(StateManager state) {super(state);}
    public synchronized void enter(int id) throws InterruptedException {
       while(getPhilo() >= 4) wait();
        begin(id);
        setPhilo(getPhilo()+1);
    }
    public synchronized void exit(int id)  {
        end(id);
        setPhilo(getPhilo()-1);
    }
    public int getPhilo(){
        return filosofos;
    }
    public synchronized void setPhilo(int i){
        filosofos = i;
    }
}
