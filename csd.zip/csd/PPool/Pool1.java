// CSD feb 2015 Juansa Sendra

public class Pool1 extends Pool {   //no kids alone
    int instructores = 0;
    int kids = 0;
    public void init(int ki, int cap)           {}
    public synchronized void kidSwims() throws InterruptedException {
        while(instructores == 0){
            log.waitingToSwim();
            wait();
        }
        kids++;
        log.swimming();
    }
    public synchronized void kidRests()  throws InterruptedException{
        kids--;
        notifyAll();
        log.resting(); 
    }
    public synchronized void instructorSwims() throws InterruptedException {
        instructores++;
        notifyAll();
        log.swimming();
    }
    public synchronized void instructorRests() throws InterruptedException  {
        while(kids > 0 && instructores == 1){
            log.waitingToRest();
            wait();
        }
        instructores--;
        log.resting(); }
}
