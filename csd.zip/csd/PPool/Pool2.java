// CSD feb 2015 Juansa Sendra

public class Pool2 extends Pool{ //max kids/instructor
    int instructores = 0;
    int kids = 0;
    public void init(int ki, int cap)           {}
    public synchronized void kidSwims() throws InterruptedException {
        while(instructores == 0){
            log.waitingToSwim();
            wait();
        }
        while(kids / instructores == 2){
            log.waitingToSwim();
            wait();
        }
        kids++;
        log.swimming();
    }
    public synchronized void kidRests()  throws InterruptedException{
        kids--;
        notifyAll();
        log.resting(); 
    }
    public synchronized void instructorSwims() throws InterruptedException {
        instructores++;
        notifyAll();
        log.swimming();
    }
    public synchronized void instructorRests() throws InterruptedException  {
        while(kids > 0 && instructores == 1){
            log.waitingToRest();
            wait();
        }
        if(instructores != 1){
            while(((double)kids / (instructores-1)) > 2.0){
                log.waitingToRest();
                wait();
            }
        }
        instructores--;
        log.resting(); }
}

