// CSD feb 2013 Juansa Sendra

public class Pool4 extends Pool { //kids cannot enter if there are instructors waiting to exit
int instructores = 0;
int kids = 0; int instesperando = 0;
    public void init(int ki, int cap)           {}
    public synchronized void kidSwims() throws InterruptedException {
        while(instructores == 0){
            log.waitingToSwim();
            wait();
        }
        while((kids / instructores) == 2 || kids + instructores == 5 || instesperando > 0){
            log.waitingToSwim();
            wait();
            while(instructores == 0){
                log.waitingToSwim();
                wait();
            }
        }
 
        kids++;
        log.swimming();
    }
    public synchronized void kidRests()  throws InterruptedException{
        kids--;
        notifyAll();
        log.resting(); 
    }
    public synchronized void instructorSwims() throws InterruptedException {
        while(kids + instructores == 5){
            log.waitingToSwim();
            wait();
        }
        instructores++;
        notifyAll();
        log.swimming();
    }
    public synchronized void instructorRests() throws InterruptedException  {
        if(kids > 0 && instructores == 1){
            instesperando++;
            while(kids > 0 && instructores == 1){
                log.waitingToRest();
                wait();
            }
            instesperando--;
        }
        if(instructores != 1){
            if(((double)kids / (instructores-1)) > 2.0){
                instesperando++;
                while(((double)kids / (instructores-1)) > 2.0){
                    log.waitingToRest();
                    wait();
                }
                instesperando--;
            }
            }
        instructores--;
        notifyAll();
        log.resting(); }
}
